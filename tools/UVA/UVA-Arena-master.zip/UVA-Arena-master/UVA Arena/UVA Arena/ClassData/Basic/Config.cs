﻿namespace UVA_Arena
{
    class Config
    {
        public const string uHuntBaseUrl = "https://uhunt.onlinejudge.org";
    }
}
