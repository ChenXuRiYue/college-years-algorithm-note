# 2.1 第 3 章 数组和字符串


- 习题 3-1 得分(Score, ACM/ICPC Seoul 2005, UVa1585)
- 习题 3-2 分子量(Molar Mass, ACM/ICPC Seoul 2007, UVa1586)
- 习题 3-3 数数字(Digit Counting , ACM/ICPC Danang 2007, UVa1225)
- 习题 3-4 周期串(Periodic Strings, UVa455)
- 习题 3-5 谜题(Puzzle, ACM/ICPC World Finals 1993, UVa227)
- 习题 3-6 纵横字谜的答案(Crossword Answers, ACM/ICPC World Finals 1994, UVa232)
- 习题 3-7 DNA 序列(DNA Consensus String, ACM/ICPC Seoul 2006, UVa1368)
- 习题 3-8 循环小数(Repeating Decimals, ACM/ICPC World Finals 1990, UVa202)
- 习题 3-9 子序列(All in All, UVa10340)
- 习题 3-10 盒子(Box, ACM/ICPC NEERC 2004, UVa1587)
- 习题 3-11 换低挡装置(Kickdown, ACM/ICPC NEERC 2006, UVa1588)
- 习题 3-12 浮点数(Floating-Point Numbers, UVa11809)
