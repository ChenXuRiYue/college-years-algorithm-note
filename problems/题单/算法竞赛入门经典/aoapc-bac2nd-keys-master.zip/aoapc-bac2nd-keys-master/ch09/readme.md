# 2.7 第 9 章动态规划初步
- 习题 9-1 最长的滑雪路径(Longest Run on a Snowboard, UVa 10285)
- 习题 9-2 免费糖果(Free Candies, UVa10118)
- 习题 9-3 切蛋糕(Cake Slicing, ACM/ICPC Nanjing 2007, UVa1629)
- 习题 9-4 串折叠(Folding, ACM/ICPC NEERC 2001, UVa1630)
- 习题 9-5 邮票和信封(Stamps and Envelope Size, ACM/ICPC World Finals 1995, UVa242)
- 习题 9-6 电子人的基因(Cyborg Genes, UVa10723)
- 习题 9-8 阿里巴巴(Alibaba, ACM/ICPC SEERC 2004, UVa1632)
- 习题 9-9 仓库守卫(Storage Keepers, UVa10163)
- 习题 9-10 照亮体育馆(Barisal Stadium, UVa10641)
- 习题 9-11 禁止的回文子串(Dyslexic Gollum, ACM/ICPC Amritapuri 2012, UVa1633) 
- 习题 9-12 保卫 Zonk(Protecting Zonk, ACM/ICPC Dhaka 2006, UVa12093) 
- 习题 9-14 圆和多边形(Telescope, ACM/ICPC Tsukuba 2000, UVa1543)
- 习题 9-15 学习向量(Learning Vector, ACM/ICPC Dhaka 2012, UVa12589)
- 习题 9-18 棒球投手(Pitcher Rotation, ACM/ICPC Kaosiung 2006, UVa1379)

## TODO

### 补充题解/证明

### 代码&题解
- [x] 习题 9- 7 　 密码锁（ Locker, Tianjin 2012, UVa1631）
- [ ] 习题 9- 13 　 叠 盘子（ Stacking Plates, ACM/ ICPC World Finals 2012, UVa1289）
- [ ] 习题 9- 16 　 野餐（ The Picnic, ACM/ ICPC NWERC 2002, UVa1634）
- [ ] 习题 9- 17 　 佳佳的筷子（ Chopsticks, UVa 10271）
- [ ] 习题 9- 19 　 花环（ Garlands, ACM/ ICPC CERC 2009, UVa1443）
- [x] 习题 9- 20 　 山路（ Mountain Road, NWERC 2009, UVa12222）
- [x] 习题 9- 21 　 周期（ Period, ACM/ ICPC Seoul 2006, UVa1371）
- [x] 习题 9- 22 　 俄罗斯 套 娃（ Matryoshka, ACM/ ICPC World Finals 2013, UVa 1579）
- [x] 习题 9- 23 　 优化最大值电路（ Minimizing Maximizer, ACM/ ICPC CERC 2003, UVa1322）

