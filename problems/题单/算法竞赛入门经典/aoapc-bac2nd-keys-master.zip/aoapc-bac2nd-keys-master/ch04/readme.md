# 2.2 第 4 章 函数和递归


- 习题 4-1 象棋(Xiangqi, ACM/ICPC Fuzhou 2011, UVa1589)
- 习题 4-2 正方形(Squares, ACM/ICPC World Finals 1990, UVa201)
- 习题 4-3 黑白棋(Othello, ACM/ICPC World Finals 1992, UVa220)
- 习题 4-4 骰子涂色(Cube painting, UVa253)
- 习题 4-5 IP 网络(IP Networks, ACM/ICPC NEERC 2005, UVa1590)
- 习题 4-6 莫尔斯电码(Morse Mismatches, ACM/ICPC World Finals 1997, UVa508)
- 习题 4-7 RAID 技术(RAID!, ACM/ICPC World Finals 1997, UVa509)
- 习题 4-8 特别困的学生 (Extraordinarily Tired Students, ACM/ICPC Xi’an 2006, UVa12108)
- 习题 4-9 数据 挖掘（ Data Mining, ACM/ ICPC NEERC 2003, UVa1591)
- 习题 4-10 洪水！(Flooded! ACM/ICPC World Finals 1999, UVa815)

## 补充题解
- [x] 习题 4-9 数据 挖掘（ Data Mining, ACM/ ICPC NEERC 2003, UVa1591)

