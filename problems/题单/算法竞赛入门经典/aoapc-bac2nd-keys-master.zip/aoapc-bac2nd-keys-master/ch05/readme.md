# 2.3 第 5 章 C++与 STL 入门

 - 习题 5-1 代码对齐(Alignment of Code, ACM/ICPC NEERC 2010, UVa1593)        
 - 习题 5-2 Ducci 序列(Ducci Sequence, ACM/ICPC Seoul 2009, UVa1594)       
 - 习题 5-3 卡片游戏(Throwing cards away I, UVa10935)                        
 - 习题 5-4 交换学生(Foreign Exchange, UVa10763)                             
 - 习题 5-5 复合词(Compound Words, UVa 10391)                               
 - 习题 5-6 对称轴(Symmetry, ACM/ICPC Seoul 2004, UVa1595)                  
 - 习题 5-7 打印队列(Printer Queue, ACM/ICPC NWERC 2006, UVa12100)           
 - 习题 5-8 图书管理系统(Borrowers, ACM/ICPC World Finals 1994, UVa230)        
 - 习题 5-9 找 bug(Bug Hunt, ACM/ICPC Tokyo 2007, UVa1596)                
 - 习题 5-10 在 Web 中搜索(Searching the Web, ACM/ICPC Beijing 2004, UVa1597)
 - 习题 5-11 更新字典(Updating a Dictionary, UVa12504)                       
 - 习题 5-12 地图查询(Do You Know The Way to San Jose?, ACM/ICPC World Finals
 - 习题 5-13 客户中心模拟(Queue and A, ACM/ICPC World Finals 2000, UVa822)     
 - 习题 5-14 交易所(Exchange, ACM/ICPC NEERC 2006, UVa1598)                 
 - 习题 5-15 Fibonacci 的复仇(Revenge of Fibonacci, ACM/ICPC Shanghai 2011, 
 - 习题 5-16 医院设备利用(Use of Hospital Facilities, ACM/ICPC World Finals 199

## TODO