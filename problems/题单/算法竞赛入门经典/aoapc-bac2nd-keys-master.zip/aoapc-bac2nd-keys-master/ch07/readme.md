# 2.5 第 7 章 暴力求解法

 - 习题 7-1 消防车(Firetruck, ACM/ICPC World Finals 1991, UVa208) 
 - 习题 7-2 黄金图形(Golygons, ACM/ICPC World Finals 1993, UVa225)
 - 习题 7-3 多米诺效应(The Domino Effect, ACM/ICPC World Finals 1991, UVa211)
 - 习题 7-4 切断圆环链(Cutting Chains, ACM/ICPC World Finals 2000, UVa818)
 - 习题 7-5 流水线调度(Pipeline Scheduling, UVa690)
 - 习题 7-6 重叠的正方形 (Overlapping Squares, Xi’an 2006, UVa12113)
 - 习题 7-10 守卫棋盘(Guarding the Chessboard, UVa11214)
 - 习题 7-11 树上的机器人规划（简单版）(Planning mobile robot on Tree (EASY Version), UVa12569)
 - 习题 7-12 移动小球(Moving Pegs, ACM/ICPC Taejon 2000, UVa1533)
 - 习题 7-15 最大的数(Biggest Number, UVa11882)
 - 习题 7-18 推门游戏(The Wall Pusher, UVa10384)

## TODO

### 补充题解

- [ ] 习题 7- 7 　 埃及分数（ Eg[ y] ptian Fractions (HARD version), Rujia Liu' s Present 6, UVa 12558）
- [ ] 习题 7- 8 　 数字谜（ Digit Puzzle, ACM/ ICPC Xi' an 2006, UVa12107）
- [ ] 习题 7- 9 　 立体八数码问题（ Cubic Eight- Puzzle , ACM/ ICPC Japan 2006, UVa1604）
- [ ] 习题 7-13     数字表达式（According to Bartjens, ACM/ICPC World Finals 2000, UVa817）
- [x] 习题 7-14 　 小木棍（ Sticks, ACM/ ICPC CERC 1995, UVa 307）
- [x] 习题 7-16 　 找座位（ Finding Seats Again, UVa11846）
- [x] 习题 7-17 　Gokigen Naname 谜题（ Gokigen Naname, UVa11694）


